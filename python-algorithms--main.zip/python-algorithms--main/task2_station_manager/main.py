from models import FuelDispenser, CarWash

# Create assets
fuel = FuelDispenser(200, 650)   # 200 liters at ₦650
wash = CarWash(30, 1500)         # 30 cars at ₦1500

assets = [fuel, wash]

total_revenue = 0

for asset in assets:
    total_revenue += asset.calculate_revenue()

print("Total Station Revenue:", total_revenue)