from abc import ABC, abstractmethod

# Abstract Base Class
class StationAsset(ABC):

    @abstractmethod
    def calculate_revenue(self):
        pass


# Fuel Dispenser
class FuelDispenser(StationAsset):

    def __init__(self, liters_sold, price_per_liter):
        self.liters_sold = liters_sold
        self.price_per_liter = price_per_liter

    def calculate_revenue(self):
        return self.liters_sold * self.price_per_liter


# Car Wash
class CarWash(StationAsset):

    def __init__(self, cars_washed, price_per_car):
        self.cars_washed = cars_washed
        self.price_per_car = price_per_car

    def calculate_revenue(self):
        return self.cars_washed * self.price_per_car