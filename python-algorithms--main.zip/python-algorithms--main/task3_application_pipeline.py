from collections import deque

# Step 1: Initialize
application_inbox = deque()
processed_history = []

# Step 2: Ingest messy data
startups = [" TechCorp ", "bio-gen", " AI Labs ", " FutureTech "]

for name in startups:
    clean_name = name.strip().lower()
    application_inbox.append(clean_name)

print("Applications received:", list(application_inbox))


# Step 3: Process (FIFO)
while application_inbox:
    app = application_inbox.popleft()
    print("Approving:", app)
    processed_history.append(app)


# Step 4: Undo (LIFO)
last = processed_history.pop()
print("Reverting approval for:", last)