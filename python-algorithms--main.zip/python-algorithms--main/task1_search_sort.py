import random

# Step 1: Generate random candidate scores
scores = [random.randint(1, 100) for _ in range(10)]
print("Generated Scores:", scores)

# Step 2: Merge Sort (recursive)
def merge_sort(arr):
    if len(arr) <= 1:
        return arr

    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])

    return merge(left, right)

def merge(left, right):
    result = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])

    return result


# Step 3: Binary Search
def binary_search(arr, target):
    low = 0
    high = len(arr) - 1

    while low <= high:
        mid = (low + high) // 2

        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1

    return -1


# Sort scores
sorted_scores = merge_sort(scores)
print("Sorted Scores:", sorted_scores)

# Step 4: Ask user for score
target = int(input("Enter score to find: "))

rank = binary_search(sorted_scores, target)

if rank != -1:
    print(f"Candidate with score {target} found at rank {rank}.")
else:
    print("Score not found.")